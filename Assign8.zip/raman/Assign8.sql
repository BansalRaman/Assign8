create table user(ID int(10) unsigned NOT NULL AUTO_INCREMENT PRIMARY KEY, fname varchar(255), lname varchar(255), email varchar (255), password varchar(20));
insert into user values(NULL,"Raman", "Bansal", "raman@gmail.com", "raman@123")
insert into user values(NULL,"Nitya", "Kumar", "nitya@gmail.com", "nitya@123")
insert into user values(NULL,"Pradeep", "Maurya", "pradeep@gmail.com", "pradeep@123")
insert into user values(NULL,"Anuj", "Sharma", "anuj@gmail.com", "anuj@123")