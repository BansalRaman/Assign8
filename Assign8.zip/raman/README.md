# database
Php with sql
While running prerequisite are php, mysql
Step 1- Create database with name db and create a table user
Step 2- Ensure Connection of the php files with the databse
Step 3- While connecting makesure to add your username and password
Step 4- Start by registering the user using the reg.php
Step 5- Login and there are option to change your details in the home page after you logged in successfully
